import json,os
D="https://fixmyspeakercleaner.com.in"
NAV=[("/","Home"),("/#fix-my-speaker","Fix My Speaker"),("/#speaker-test","Speaker Test"),("/about-us/","About Us"),("/contact-us/","Contact Us")]
FOOT=[("/about-us/","About Us"),("/contact-us/","Contact Us"),("/privacy-policy/","Privacy Policy"),("/terms-and-conditions/","Terms and Conditions")]
def page(path,title,desc,body,crumb=None,extra=""):
    url=D+path
    nav="".join(f'<a href="{h}"{" aria-current=\"page\"" if h==path else ""}>{t}</a>' for h,t in NAV)
    foot="".join(f'<a href="{h}">{t}</a>' for h,t in FOOT)
    ld=[{"@context":"https://schema.org","@type":"WebSite","name":"Fix My Speaker","url":D+"/"},
        {"@context":"https://schema.org","@type":"Organization","name":"Fix My Speaker","url":D+"/","logo":D+"/assets/icon-512.png"}]
    if crumb: ld.append({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":D+"/"},{"@type":"ListItem","position":2,"name":crumb,"item":url}]})
    bc=f'<nav class="crumb w" aria-label="Breadcrumb"><a href="/">Home</a> / {crumb}</nav>' if crumb else ""
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><meta name="description" content="{desc}"><link rel="canonical" href="{url}">
<meta property="og:type" content="website"><meta property="og:title" content="{title}"><meta property="og:description" content="{desc}"><meta property="og:url" content="{url}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{title}"><meta name="twitter:description" content="{desc}">
<link rel="icon" href="/favicon.ico" sizes="any"><link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32.png"><link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon-16.png"><link rel="apple-touch-icon" href="/assets/apple-touch-icon.png"><link rel="manifest" href="/manifest.webmanifest"><meta name="theme-color" content="#1668e3">
<meta property="og:image" content="{D}/assets/og-image.png"><meta name="twitter:image" content="{D}/assets/og-image.png">
<link rel="stylesheet" href="/assets/style.css">{extra}
<script type="application/ld+json">{json.dumps(ld)}</script></head><body>
<header><div class="w"><a class="logo" href="/"><img src="/assets/logo-72.png" width="36" height="36" alt="Fix My Speaker logo, a speaker icon with sound waves"><span>Fix My Speaker</span></a><nav aria-label="Main">{nav}</nav></div></header>
{bc}<main>{body}</main>
<footer><div class="w"><span class="mut">Fix My Speaker. Free browser-based speaker tools.</span><nav aria-label="Footer">{foot}</nav></div></footer>
<script src="/assets/app.js" defer></script></body></html>'''
def w(p,html):
    os.makedirs("."+p,exist_ok=True);open("."+p+"index.html","w").write(html)

faq=[("Can this tool really remove water from my phone speaker?","It plays a low-frequency sound that makes the speaker cone vibrate, which can help push out water near the grille. It cannot guarantee results or repair damaged hardware."),
("Is it safe for my speaker?","Use a moderate volume and stop if you hear crackling or distortion. Avoid maximum volume and long sessions."),
("How long should I run it?","Run a full session of about one minute, wipe the grille, then repeat two or three times if needed."),
("Does the tool upload or record my audio?","No. The sounds play in your browser. Nothing is recorded or sent from your device."),
("Which mode should I use?","Use Water Eject after water exposure and Dust Removal when the sound has gradually become quiet or dull."),
("Why do the left and right tests sound the same?","Most phones have one speaker or mix channels. Use headphones for a reliable stereo test."),
("Will it work on iPhone and Android?","Yes. It works in current Safari, Chrome, Firefox and Edge. Turn off silent mode and raise the media volume first."),
("What if my speaker still sounds muffled?","Let the phone dry in open air without heat, then contact the manufacturer or a repair technician if the problem continues.")]
fq="".join(f"<details><summary>{q}</summary><p>{a}</p></details>" for q,a in faq)
fld={"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":q,"acceptedAnswer":{"@type":"Answer","text":a}} for q,a in faq]}
EXTRA=open('home_extra.html').read().replace('{FAQ}',fq)
home=f'''<section><div class="w"><h1>Fix My Speaker Online</h1>
<p class="mut" style="font-size:1.15rem">Play a water eject sound or a dust removal sound through your phone or computer speaker. Free, in your browser, no installation.</p></div></section>
<section id="fix-my-speaker"><div class="w"><div class="card" id="tool">
<h2>Speaker Cleaner Tool</h2>
<div class="tabs" role="tablist" aria-label="Cleaning mode"><button class="tab" role="tab" data-mode="water" aria-selected="true">Water Eject</button><button class="tab" role="tab" data-mode="dust" aria-selected="false">Dust Removal</button></div>
<div id="stbox" class="status" aria-live="polite"><span class="dot"></span><span id="st">Ready</span></div>
<p class="mut" style="margin:6px 0 14px">Active mode: <strong id="modename">Water Eject</strong></p>
<div class="bar" id="bar" role="progressbar" aria-label="Playback progress"><i></i></div>
<div class="times"><span id="cur">0:00</span><span id="rem">-0:00</span><span id="tot">0:00</span></div>
<div class="ctrls"><button class="primary" id="play">Play</button><button id="pause" disabled>Pause</button><button id="resume" disabled>Resume</button><button id="stop" disabled>Stop</button></div>
<label for="vol">Volume</label><input id="vol" type="range" min="0" max="100" value="80">
<p id="err" class="msg err" role="alert"></p>
<p class="note">Keep the phone speaker facing down, remove any case, and use a moderate volume. This tool may help clear water or dust but cannot repair hardware or guarantee results. Audio loads only when you press Play.</p>
</div></div></section>
<section id="speaker-test"><div class="w"><h2>Speaker Test Online</h2>
<div class="card"><p class="mut">Tones are generated in your browser and stop automatically after 8 seconds.</p>
<div class="ctrls"><button data-t="s" data-f="440">Sound Test</button><button data-t="l" data-f="440" data-p="-1">Left Speaker</button><button data-t="r" data-f="440" data-p="1">Right Speaker</button><button data-t="st" data-f="440">Stereo</button><button data-t="b" data-f="60">Bass</button><button data-t="freq">Frequency</button></div>
<label for="fq">Frequency: <span id="fqv">1000 Hz</span></label><input id="fq" type="range" min="20" max="8000" value="1000">
<label for="tvol">Test volume</label><input id="tvol" type="range" min="0" max="100" value="40">
<div class="ctrls"><button id="tstop">Stop test</button></div><p id="tstat" class="mut" aria-live="polite">Stopped</p><p id="terr" class="msg err"></p>
<p class="note">Left and right tests need stereo hardware. Many phones mix both channels into one speaker, so use headphones for reliable results.</p></div></div></section>
{EXTRA}
<script type="application/ld+json">{json.dumps(fld)}</script>'''
w("/",page("/","Fix My Speaker Online - Water Eject and Dust Removal Sound","Fix My Speaker is a free online speaker cleaner. Play water eject and dust removal sounds, and run speaker tests, right in your browser.",home))
def simple(p,t,d,name,h,paras):
    b=f'<section><div class="w"><h1>{h}</h1>'+"".join(f"<h2>{a}</h2><p>{b}</p>" for a,b in paras)+"</div></section>"
    w(p,page(p,t,d,b,name))
simple("/about-us/","About Us - Fix My Speaker","Learn what Fix My Speaker is, how its browser-based speaker cleaning tools work, and how we approach safety and privacy.","About Us","About Fix My Speaker",[
("Introduction","Fix My Speaker is a free website that plays sounds designed to help clear water and dust from phone and computer speakers."),
("Our tools","A water eject sound, a dust removal sound, and a set of speaker tests."),
("How it works","Your browser plays audio files and generates test tones locally. Sound vibration may help move water or dust, but results vary."),
("Safety","We recommend moderate volume and clearly state that the tool cannot repair hardware."),
("Privacy","The tools do not record or upload audio. See the <a href='/privacy-policy/'>Privacy Policy</a>."),
("Mission","To offer a simple, honest, free speaker tool."),
("Contact","Use the <a href='/contact-us/'>contact page</a>.")])
simple("/privacy-policy/","Privacy Policy - Fix My Speaker","How Fix My Speaker handles data, cookies, analytics and third-party services.","Privacy Policy","Privacy Policy",[
("Information we collect","The speaker tools collect no personal information. If you use the contact form, the details you enter are used only to reply."),
("Browser-based audio","Audio files are streamed to your browser and played locally. Nothing is recorded or uploaded."),
("Cookies, analytics and advertising","This site currently sets no cookies and runs no analytics or ads. This section will be updated if that changes."),
("Third-party services","Hosting providers may log standard server data such as IP addresses."),
("Security and your rights","We take reasonable care with data. You may request access to or deletion of anything you sent us."),
("Contact","Use the <a href='/contact-us/'>contact page</a>.")])
simple("/terms-and-conditions/","Terms and Conditions - Fix My Speaker","Terms for using Fix My Speaker, including limitations, safety and liability.","Terms and Conditions","Terms and Conditions",[
("Website usage","You may use this site for personal, lawful purposes."),
("Tool functionality and limits","The tools play sounds. They do not repair hardware and do not guarantee removal of water or dust."),
("Your responsibilities and audio safety","Use moderate volume and stop if the speaker distorts. You are responsible for your device."),
("Intellectual property","Site content and audio files belong to their owners and may not be redistributed without permission."),
("Liability","The site is provided as is. We are not liable for device damage or loss arising from its use."),
("External links and changes","We are not responsible for external sites. These terms may be updated at any time."),
("Contact","Use the <a href='/contact-us/'>contact page</a>.")])
cf='''<section><div class="w"><h1>Contact Us</h1><p>Send us a question or report a problem.</p><div class="card"><form id="cform" data-endpoint="" novalidate>
<label for="name">Name</label><input id="name" name="name" type="text" autocomplete="name"><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email">
<label for="subject">Subject</label><input id="subject" name="subject" type="text"><label for="message">Message</label><textarea id="message" name="message" rows="5"></textarea>
<input class="hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><p><button class="primary" type="submit">Send message</button></p><p id="cmsg" class="msg" role="alert"></p></form></div></div></section>'''
w("/contact-us/",page("/contact-us/","Contact Us - Fix My Speaker","Contact the Fix My Speaker team with questions or feedback.",cf,"Contact Us"))
open("robots.txt","w").write(f"User-agent: *\nAllow: /\nSitemap: {D}/sitemap.xml\n")
open("sitemap.xml","w").write('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+"".join(f"<url><loc>{D}{p}</loc></url>" for p in ["/","/about-us/","/contact-us/","/privacy-policy/","/terms-and-conditions/"])+"</urlset>")
